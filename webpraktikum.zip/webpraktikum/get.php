<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>

<body>
    <?php
    $nasis = $_POST['name'];
    $matkul = $_POST['matkul'];
    $uts = $_POST['uts'];
    $uas = $_POST['uas'];
    $praktikum = $_POST['praktikum'];


    $D1 = ['name' => 'Ahmad Dzulfikor', 'uts' => 81, 'uas' => 88, 'praktikum' => 75];
    $D2 = ['name' => 'Akbar Riyadi', 'uts' => 80, 'uas' => 89, 'praktikum' => 65];
    $D3 = ['name' => 'Ibnu Hakim', 'uts' => 70, 'uas' => 84, 'praktikum' => 72];
    $D4 = ['name' => 'Wahid Wahyudin  ', 'uts' => 85, 'uas' => 93, 'praktikum' => 78];
    $D5 = ['name' => $nasis, 'uts' => $uts, 'uas' => $uas, 'praktikum' => $praktikum];

    $nilai = [$D1, $D2, $D3, $D4, $D5];
    ?>
    <div class="container">
        <a href="get.php" class="btn btn-info">ADD</a>
        <h3>Rekap Nilai Siswa</h3>
        <table class="table table-warning">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>UTS</th>
                    <th>UAS</th>
                    <th>Nilai Praktikum</th>
                    <th>Nilai Akhir</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                foreach ($nilai as $D) {
                    echo '<tr><td>' . $no . '</td>';
                    echo '<td>' . $D['name'] . '</td>';
                    echo '<td>' . $D['uts'] . '</td>';
                    echo '<td>' . $D['uas'] . '</td>';
                    echo '<td>' . $D['praktikum'] . '</td>';
                    $nilai_akhir = ($D['uts'] + $D['uas'] + $D['praktikum']) / 3;
                    echo '<td>' . number_format($nilai_akhir, 2, ',', '.') . '</td>';
                    echo '<tr/>';
                    $no++;
                }
                ?>
            </tbody>
        </table>
    </div>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>